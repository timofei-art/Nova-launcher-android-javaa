package com.nova.launcher

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val backgroundColor = Color.rgb(12, 10, 22)
    private val accentColor = Color.rgb(150, 92, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(backgroundColor)
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 32)
        }

        val logo = TextView(this).apply {
            text = "✦ NOVA"
            textSize = 32f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        content.addView(logo, matchWrap())

        val subtitle = TextView(this).apply {
            text = "MINECRAFT JAVA LAUNCHER"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        content.addView(subtitle, matchWrap())

        addSection(content, "Добро пожаловать в NOVA", "Это стартовый прототип интерфейса. Функции запуска Minecraft, загрузки модов и AI пока не подключены.")
        addAction(content, "▶  Играть", "Кнопка запуска пока демонстрационная.")
        addAction(content, "▦  Mod Store", "Магазин модов будет добавлен в следующих версиях.")
        addAction(content, "✦  AI Mod Studio", "Редактор модов пока находится в плане проекта.")
        addAction(content, "⚙  Настройки", "Настройки устройства и производительности появятся позже.")

        val footer = TextView(this).apply {
            text = "NOVA Launcher • Prototype 0.1.0"
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 0)
        }
        content.addView(footer, matchWrap())

        scroll.addView(content)
        setContentView(scroll)
    }

    private fun addSection(parent: LinearLayout, title: String, description: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(29, 24, 45))
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val body = TextView(this).apply {
            text = description
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 0)
        }
        card.addView(heading, matchWrap())
        card.addView(body, matchWrap())
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 16 }
        parent.addView(card, params)
    }

    private fun addAction(parent: LinearLayout, label: String, message: String) {
        val button = Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(accentColor)
            setOnClickListener {
                android.widget.Toast.makeText(this@MainActivity, message, android.widget.Toast.LENGTH_LONG).show()
            }
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 10 }
        parent.addView(button, params)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
