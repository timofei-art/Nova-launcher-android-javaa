# NOVA Launcher — Android starter project

This is a small Android/Kotlin starter project for the NOVA Launcher concept.

## Important
This is **not** the complete NOVA Launcher yet. It is only a basic installable prototype screen.
Minecraft Java launching, account login, mod downloading, AI features, editors, server features,
and the other items in the NOVA plan are not implemented in this starter.

## Build an APK with GitHub from your phone

1. Create a GitHub repository named `NOVA-Launcher`.
2. Upload the **contents** of this ZIP to the repository root (the files `settings.gradle.kts`,
   `build.gradle.kts`, `app/`, `.github/`, etc. must be at the top level).
3. Open the repository's **Actions** tab.
4. Choose **Build NOVA APK** and tap **Run workflow**, or push a commit to `main`.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, find **Artifacts**, and download
   `NOVA-Launcher-debug-APK`.
7. Extract the downloaded ZIP on your Android phone and install the APK.

## Technical notes
- Package: `com.nova.launcher`
- Minimum Android version: Android 6.0 (API 23)
- Compile SDK: 35
- Java: 17
- Gradle: 8.7
- The generated debug APK is for testing. A release APK should later be signed securely.

Do not upload signing keystores, passwords, API keys, or private account credentials to GitHub.
